import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np

def make_mask(h,w):
    mask = torch.ones([1,1,h,w]).cuda()
    mask[:,:,h // 2, w // 2] = 0
    return mask
def make_mask_DCL(stride_h,stride_w):
    mask = torch.ones([1,1,2*stride_h-1,3+2*(stride_w-1)]).cuda()
    mask[:,:,:, mask.shape[3]//2+1:mask.shape[3]//2+(stride_w-1)+1] = 0
    mask[:,:,:, mask.shape[3]//2-(stride_w-1):mask.shape[3]//2] = 0
    return mask



class CBSN(nn.Module):
    def __init__(self, in_ch=1, out_ch=1, base_ch=64, num_module=9,s_h1=2,s_h2=2,s_w1=2,s_w2=3):
        '''
        Args:
            in_ch      : number of input channel
            out_ch     : number of output channel
            base_ch    : number of base channel
            num_module : number of modules in the network
        '''
        super().__init__()

        assert base_ch%2 == 0, "base channel should be divided with 2"

        ly = []
        ly += [ nn.Conv2d(in_ch, base_ch, kernel_size=1) ]
        ly += [ nn.ReLU(inplace=True) ]
        self.head = nn.Sequential(*ly)

        self.branch1 = DC_branchl(s_h1,s_w1, base_ch, num_module)
        self.branch2 = DC_branchl(s_h2,s_w2, base_ch, num_module)

        ly = []
        ly += [ nn.Conv2d(base_ch*2,  base_ch,    kernel_size=1) ]
        ly += [ nn.ReLU(inplace=True) ]
        ly += [ nn.Conv2d(base_ch,    base_ch//2, kernel_size=1) ]
        ly += [ nn.ReLU(inplace=True) ]
        ly += [ nn.Conv2d(base_ch//2, base_ch//2, kernel_size=1) ]
        ly += [ nn.ReLU(inplace=True) ]
        ly += [ nn.Conv2d(base_ch//2, out_ch,     kernel_size=1) ]
        self.tail = nn.Sequential(*ly)

    def forward(self, x,is_masked=True):
        if is_masked:
            mask3 = make_mask(1,3)
            mask5 = make_mask(1,5)
            mask_1_w_3=make_mask_DCL(1,2)
            mask_h_w_3=make_mask_DCL(2,2)
            mask_1_w_5=make_mask_DCL(1,3)
            mask_h_w_5=make_mask_DCL(2,3)

        else:
            mask3 = 1
            mask5 = 1
            mask_1_w_3=1
            mask_h_w_3=1
            mask_1_w_5=1
            mask_h_w_5=1
        x = self.head(x)
        br1 = self.branch1(x,mask3,mask_1_w_3,mask_h_w_3)
        br2 = self.branch2(x,mask5,mask_1_w_5,mask_h_w_5)
        x = torch.cat([br1, br2], dim=1)
        return self.tail(x)

    def _initialize_weights(self):

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                # n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, (2 / (9.0 * 64)) ** 0.5)

class DC_branchl(nn.Module):
    def __init__(self, stride_h, stride_w,in_ch, num_module):
        super().__init__()
        self.masked_net= MaskedConv2d(in_ch, in_ch, kernel_size=(1,2*stride_w-1), padding=(0,stride_w-1)) 
        ly = []
        ly += [ nn.ReLU(inplace=True) ]
        ly += [ nn.Conv2d(in_ch, in_ch, kernel_size=1) ]
        ly += [ nn.ReLU(inplace=True) ]
        ly += [ nn.Conv2d(in_ch, in_ch, kernel_size=1) ]
        ly += [ nn.ReLU(inplace=True) ]
        self.body1 = nn.Sequential(*ly)
        self.DCL1= DCl(1,stride_w, in_ch)
        self.DCL2= DCl(1,stride_w, in_ch)
        self.DCL3= DCl(1,stride_w, in_ch)
        self.DCL4= DCl(1,stride_w, in_ch)
        self.DCL5= DCl(1,stride_w, in_ch)
        self.DCL6= DCl(1,stride_w, in_ch)
        self.DCL7=DCl(stride_h,stride_w, in_ch)
        self.DCL8=DCl(stride_h,stride_w, in_ch)
        self.DCL9=DCl(stride_h,stride_w, in_ch)
        lz=[]
        lz += [ nn.Conv2d(in_ch, in_ch, kernel_size=1) ]
        lz += [ nn.ReLU(inplace=True) ]
        self.body2 = nn.Sequential(*lz)
        

    def forward(self, x,weight_mask,weight_mask_1,weight_mask_2):              
        x=self.masked_net(x,weight_mask)
        x=self.body1(x)
        x=self.DCL1(x,weight_mask_1)
        x=self.DCL2(x,weight_mask_1)
        x=self.DCL3(x,weight_mask_1)
        x=self.DCL4(x,weight_mask_1)
        x=self.DCL5(x,weight_mask_1)
        x=self.DCL6(x,weight_mask_1)
        x=self.DCL7(x,weight_mask_2)
        x=self.DCL8(x,weight_mask_2)
        x=self.DCL9(x,weight_mask_2)
        return self.body2(x)

class DCl(nn.Module):
    def __init__(self, stride_h, stride_w, in_ch):
        super().__init__()
        self.masked_DCL=MaskedConv_DCL(in_ch,in_ch,stride_h, stride_w)
        ly = []      
        ly += [ nn.ReLU(inplace=True) ]
        ly += [ nn.Conv2d(in_ch, in_ch, kernel_size=1) ]
        self.body = nn.Sequential(*ly)

    def forward(self, x,weight_mask_DCL):
        y=self.masked_DCL(x,weight_mask_DCL)
        return x + self.body(y)

    

    
class MaskedConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size,padding):
        super(MaskedConv2d, self).__init__()

        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, padding=padding)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.normal_(m.weight, mean=0, std=np.sqrt(2 / np.prod(m.weight.shape[:-1])))
            nn.init.zeros_(m.bias)

    def forward(self, x , weight_mask):

        weight = self.conv.weight * weight_mask
        x = F.conv2d(x, weight, self.conv.bias, self.conv.stride, self.conv.padding)
        return x

    
class MaskedConv_DCL(nn.Module):
    def __init__(self, in_channels, out_channels,stride_h, stride_w):
        super(MaskedConv_DCL, self).__init__()

        self.conv=nn.Conv2d(in_channels, out_channels, kernel_size=(2*stride_h-1,3+2*(stride_w-1)), stride=(1,1), padding=(stride_h-1,stride_w))
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.normal_(m.weight, mean=0, std=np.sqrt(2 / np.prod(m.weight.shape[:-1])))
            nn.init.zeros_(m.bias)

    def forward(self, x , weight_mask):

        weight = self.conv.weight * weight_mask
        x = F.conv2d(x, weight, self.conv.bias, self.conv.stride, self.conv.padding)
        return x

