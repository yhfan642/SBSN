import torch
import torch.nn.functional as F
import math
import numpy as np
def pixel_shuffle_down_sampling_single_direction(x, factor, direction='width'):
    """
    单方向像素洗牌下采样，输出大小与输入相同
    参数:
        x (torch.Tensor): 输入张量，形状为 [B, C, H, W]
        factor (int): 下采样因子
        direction (str): 下采样方向，'width' 或 'height'
    返回:
        下采样的张量，形状与输入相同
    """
    b, c, h, w = x.shape

    if direction == 'width':
        # 检查宽度是否可以被因子整除
        assert w % factor == 0, "Width must be divisible by the factor"
        
        # 重新排列和重塑张量
        x = x.view(b, c, h, w // factor, factor)
        x = x.permute(0, 1, 2, 4, 3)
        x = x.contiguous().view(b, c, h, w)
    
    elif direction == 'height':
        # 检查高度是否可以被因子整除
        assert h % factor == 0, "Height must be divisible by the factor"
        
        # 重新排列和重塑张量
        x = x.view(b, c, h // factor, factor, w)
        x = x.permute(0, 1, 3, 2, 4)
        x = x.contiguous().view(b, c, h, w)

    return x


def pixel_shuffle_up_sampling_single_direction(x, factor, direction='width'):
    """
    单方向像素洗牌上采样
    参数:
        x (torch.Tensor): 输入张量，形状为 [B, C, H, W]
        factor (int): 上采样因子
        direction (str): 上采样方向，'width' 或 'height'
    返回:
        上采样的张量
    """
    b, c, h, w = x.shape

    if direction == 'width':
        # 检查通道数是否可以被因子整除
        assert w % factor == 0, "Width  must be divisible by the factor"
        factor=w//factor
        x = x.view(b, c, h, w // factor, factor)
        x = x.permute(0, 1, 2, 4, 3)
        x = x.contiguous().view(b, c, h, w)
    elif direction == 'height':
        # 检查高度是否可以被因子整除
        assert h % factor == 0, "Height must be divisible by the factor"
        factor=h//factor
        x = x.view(b, c, h // factor, factor, w)
        x = x.permute(0, 1, 3, 2, 4)
        x = x.contiguous().view(b, c, h, w)

    return x



def pixel_shuffle_down_sampling(x, factor):
    b,c,h,w=x.shape
    x=pixel_shuffle_down_sampling_single_direction(x,factor[0], direction='height')
    x=pixel_shuffle_down_sampling_single_direction(x,factor[1], direction='width')
    # copy=x.clone()
    # div=int(w*(factor[1]//2)/factor[1])
    # step=int(h/factor[0])
    # for cnt in torch.arange(2, factor[0]+1, 2):
    #     x[:,:,(cnt-1)*step:cnt*step,:]=torch.cat((copy[:,:,(cnt-1)*step:cnt*step,div:],copy[:,:,(cnt-1)*step:cnt*step,:div]),3) 
    return x   
    
def pixel_shuffle_up_sampling(x, factor):
    b,c,h,w=x.shape
    # copy=x.clone()
    # div=math.ceil(w*(factor[1]//2)/factor[1])
    # step=int(h/factor[0])
    # for cnt in torch.arange(2, factor[0]+1, 2):
    #     x[:,:,(cnt-1)*step:cnt*step,:]=torch.cat((copy[:,:,(cnt-1)*step:cnt*step,div:],copy[:,:,(cnt-1)*step:cnt*step,:div]),3)
    x=pixel_shuffle_up_sampling_single_direction(x,factor[1], direction='width')
    x=pixel_shuffle_up_sampling_single_direction(x,factor[0], direction='height')
    return x 

def normalize(img):
    # Calculate the mean and standard deviation along the spatial dimensions (H and W)
    mean = torch.mean(img, dim=[2, 3], keepdim=True)
    std = torch.std(img, dim=[2, 3], keepdim=True)

    # Ensure the standard deviation is not too small to avoid division by zero
    std = torch.maximum(std, 1 / torch.sqrt(torch.tensor(img.shape[2] * img.shape[3])))

    # Normalize the image
    img_norm = (img - mean) / std

    return img_norm, mean, std
