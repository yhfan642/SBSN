import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from scipy.signal import chirp, correlate


def STFT_f(signal,n_fft,hop,win,title='STFT'):
    window = torch.hann_window(win)
    specgram = torch.stft(signal, n_fft, hop, win, window, return_complex=True)

    magnitude = torch.abs(specgram)
    plt.figure(figsize=(10, 4))
    plt.imshow(magnitude.numpy(), aspect='auto', origin='lower')
    plt.colorbar(label='Magnitude')
    # plt.clim([-10,30])
    plt.xlabel('Time Frame')
    plt.ylabel('Frequency Bin')
    plt.title(title)
    plt.tight_layout()
    plt.show()
    

def SSIM(img1, img2, size_average=True):
    
    L = 2
    mm=torch.max(img2)
    img1=img1/mm
    img2=img2/mm
    if img1.dim() == 2:
        img1 = img1.unsqueeze(0).unsqueeze(0)
    if img2.dim() == 2:
        img2 = img2.unsqueeze(0).unsqueeze(0)

    mu1 = img1.mean([2, 3])
    mu2 = img2.mean([2, 3])

    sigma1_sq = ((img1 - mu1.unsqueeze(-1).unsqueeze(-1)) ** 2).mean([2, 3])
    sigma2_sq = ((img2 - mu2.unsqueeze(-1).unsqueeze(-1)) ** 2).mean([2, 3])

    sigma12 = ((img1 - mu1.unsqueeze(-1).unsqueeze(-1)) * (img2 - mu2.unsqueeze(-1).unsqueeze(-1))).mean([2, 3])
    C1 = (0.1 * L) ** 2
    C2 = (0.2 * L) ** 2

    ssim_map = ((2 * mu1 * mu2 + C1) * (sigma12 + C2)) / ((mu1 ** 2 + mu2 ** 2 + C1) * (sigma1_sq + sigma2_sq + C2))

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1)
    
def CORR(signal1,signal2):
    signal1=signal1/torch.max(signal1)#归一化
    signal2=signal2/torch.max(signal2)#归一化
    result=correlate(signal1,signal2)
    plt.figure()
    plt.plot( result)
    plt.ylim([-300,300])