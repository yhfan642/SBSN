
import torch
import torch.nn as nn
import torch.nn.functional as F

from P_shuffle import pixel_shuffle_down_sampling, pixel_shuffle_up_sampling,normalize
from SBSN_pro import CBSN


class APBSN(nn.Module):

    def __init__(self, pd_a=[4,10], pd_b=[2,8], pd_pad=0, R3=False, R3_T=2, R3_p=0.01, 
                    bsn='DBSNl', in_ch=1, bsn_base_ch=64, bsn_num_module=9):
        super().__init__()

        # network hyper-parameters
        self.pd_a    = pd_a
        self.pd_b    = pd_b
        self.pd_pad  = pd_pad
        self.R3      = R3
        self.R3_T    = R3_T
        self.R3_p    = R3_p
        
        # define network
        if bsn == 'DBSNl':
            self.bsn =CBSN(in_ch, in_ch, bsn_base_ch, bsn_num_module)
        else:
            raise NotImplementedError('bsn %s is not implemented'%bsn)

    def forward(self, img, is_masked=True,pd=None):

        b,c,h,w = img.shape

        # pad images for PD process
        # if h % self.pd_b != 0:
        #     x = F.pad(x, (0, 0, 0, self.pd_b - h%self.pd_b), mode='constant', value=0)

        if pd is None: pd = self.pd_a
        if h % pd[0] != 0:
            img = F.pad(img, (0,0, 0,pd[0] - h%pd[0]), mode='constant', value=0)
        if w % pd[1] != 0:
            img = F.pad(img, (0, pd[1] - w%pd[1], 0, 0), mode='constant', value=0)
        # do PD
        pd_img = pixel_shuffle_down_sampling(img, pd)
        # forward blind-spot network
        pd_img_denoised = self.bsn(pd_img,is_masked)

        # do inverse PD
        img_pd_bsn = pixel_shuffle_up_sampling(pd_img_denoised, pd)

        return img_pd_bsn

    def denoise(self, x):
  
        b,c,h,w = x.shape
        masked_flag=False
        # pad images for PD process
        if h % self.pd_b[0] != 0:
            x = F.pad(x, (0, 0, 0, self.pd_b[0] - h%self.pd_b[0]), mode='constant', value=0)
        if w % self.pd_b[1] != 0:
            x = F.pad(x, (0, self.pd_b[1] - w%self.pd_b[1], 0, 0), mode='constant', value=0)
        # forward PD-BSN process with inference pd factor
        img_pd_bsn = self.forward(img=x,is_masked=masked_flag, pd=self.pd_b)

        # Random Replacing Refinement
        if not self.R3:
            return img_pd_bsn[:,:,:h,:w]
        else:
            denoised = torch.empty(*(x.shape), self.R3_T, device=x.device)
            for t in range(self.R3_T):
                indice = torch.rand_like(x)
                mask = indice < self.R3_p

                tmp_input = torch.clone(img_pd_bsn).detach()
                tmp_input[mask] = x[mask]
                tmp_input, mean, std = normalize(tmp_input)#输入归一化
                p = self.pd_pad
                tmp_input = F.pad(tmp_input, (p,p,p,p), mode='reflect')
                if self.pd_pad == 0:
                    denoised[..., t] = std*self.bsn(tmp_input,is_masked=masked_flag)+mean
                else:
                    denoised[..., t] = std*self.bsn(tmp_input,is_masked=masked_flag)[:,:,p:-p,p:-p]+mean

            return torch.mean(denoised, dim=-1)
            

