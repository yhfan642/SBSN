import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
import os
import h5py
import matplotlib.pyplot as plt
import random
from SBSN import APBSN
from torch.utils.data import Dataset, DataLoader
from tool_f import SSIM

class loss_DBSN(nn.Module):
    def __init__(self):
        super(loss_DBSN, self).__init__()

    def forward(self, input_data, model_output):
        return F.l1_loss(model_output, input_data)  
class MyDataset(Dataset):
    def __init__(self, tensor1, tensor2):
        self.tensor1 = tensor1
        self.tensor2 = tensor2

    def __len__(self):
        return len(self.tensor1)

    def __getitem__(self, idx):
        return self.tensor1[idx], self.tensor2[idx]
LOSS=loss_DBSN()


file_path='train_corr_2_5_20.mat'
datafile=os.path.join(os.getcwd(),file_path)
data=h5py.File(datafile)
train_dataset=torch.tensor(data['train_data']).float()
train_dataset=train_dataset.permute(2,1,0)
train_dataset=torch.unsqueeze(train_dataset, 1)
file_path='val_corr_2_5_20.mat'
datafile=os.path.join(os.getcwd(),file_path)
data=h5py.File(datafile)

val_dataset=torch.tensor(data['val_data']).float()
val_dataset=val_dataset.permute(2,1,0)
val_dataset=torch.unsqueeze(val_dataset, 1)
ref_dataset=torch.tensor(data['ref']).float()
ref_dataset=ref_dataset.permute(2,1,0)
ref_dataset=torch.unsqueeze(ref_dataset, 1)

train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)
dataset = MyDataset(val_dataset, ref_dataset)
val_loader = DataLoader(dataset, batch_size=4, shuffle=False)


pa=[2,6]
model=APBSN(pd_a=pa).cuda()
optimizer = optim.Adam(model.parameters(), lr=5e-5)  

num_epochs =100
best_val_SSIM = 0
b,c,h,w = train_dataset.shape
for epoch in range(num_epochs):
    model.train()
    total_loss = 0.0
    self_loss = 0.0
    inv_loss = 0.0
    for batch in train_loader:
        inputs = batch.cuda()
        optimizer.zero_grad()
        masked_output=model(inputs,is_masked=True)
        un_output=model(inputs,is_masked=False)
        loss_self = LOSS(un_output[:,:,0:h,0:w],inputs)
        loss_inv = LOSS(masked_output[:,:,0:h,0:w],un_output[:,:,0:h,0:w])
        loss=loss_self+2*loss_inv
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        self_loss +=loss_self.item()
        inv_loss +=2*loss_inv.item()
    avg_train_loss = total_loss / len(train_loader)
    avg_self_loss = self_loss / len(train_loader)
    avg_inv_loss = inv_loss / len(train_loader)
    
 
    model.eval()
    total_val_SSIM = 0.0
    with torch.no_grad():
        for batch,ref in val_loader:
            inputs = batch.cuda()
            un_output=model.denoise(inputs)
            val_SSIM=SSIM(un_output.cpu(),ref) 
            total_val_SSIM += val_SSIM

    avg_val_SSIM= total_val_SSIM / len(val_loader)
    

    if epoch % 2 ==0:
        checkpoint_path = f'CPBSN_2_6_{epoch}.pth'
        torch.save(model.state_dict(), checkpoint_path)
        print(f'Saved checkpoint: {checkpoint_path}')
        

    print(f"Epoch [{epoch+1}/{num_epochs}] Train Loss: {avg_train_loss}, SSIM: {avg_val_SSIM}")
    print(f"Epoch [{epoch+1}/{num_epochs}] self Loss: {avg_self_loss}, inv Loss: {avg_inv_loss}")

print("Training complete!")


